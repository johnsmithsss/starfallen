<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Background_125" tilewidth="50" tileheight="50" tilecount="15" columns="3">
 <image source="Background_125.png" width="160" height="288"/>
</tileset>
