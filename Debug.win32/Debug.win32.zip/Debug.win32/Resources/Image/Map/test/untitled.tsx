<?xml version="1.0" encoding="UTF-8"?>
<tileset name="ForestTile" tilewidth="50" tileheight="50" tilecount="400" columns="20">
 <image source="ForestTile.png" width="1024" height="1024"/>
 <tile id="269">
  <properties>
   <property name="temp" type="bool" value="false"/>
  </properties>
 </tile>
</tileset>
