<?xml version="1.0" encoding="UTF-8"?>
<tileset name="43_0_001_1_100" tilewidth="50" tileheight="50" tilecount="4" columns="2">
 <image source="43_0_001_1_100.png" width="128" height="128"/>
</tileset>
