<?xml version="1.0" encoding="UTF-8"?>
<tileset name="43_0_001_1_100" tilewidth="40" tileheight="40" tilecount="9" columns="3">
 <image source="43_0_001_1_100.png" width="128" height="128"/>
 <tile id="3">
  <properties>
   <property name="Collidable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="Collidable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="Collidable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="Collidable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="Collidable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="Collidable" type="bool" value="false"/>
  </properties>
 </tile>
</tileset>
