<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Charactor_0" tilewidth="32" tileheight="32" tilecount="63" columns="7">
 <image source="Charactor_0.png" width="252" height="306"/>
</tileset>
